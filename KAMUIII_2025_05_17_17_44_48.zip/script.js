let particles = []; // array to hold all particles
let attractors = []; // array to hold all attractors (vortexes)
let showTrails = false; // toggle for trail effect
let mode = "calm"; // simulation mode
let seed; // random seed
let attract = true; // whether particles are attracted or repelled
let G = 1; // gravitational constant
let seedInput, seedButton, modeSelector, forceSelector; // UI elements
let gravitySlider; // gravity control slider
let swirlAngle = 0; // angle for swirling animation
let sharinganImg;
let kamuiBgImg;
let particleImgs = [];
let dimension = "kamui"; // or "earth"
let normalSharingan = false; // sharingan mode toggle
let gravity = 9.8; // separate variable for gravity
let attractionForce = 1; // attraction force only applies with Mangekyo
let attractionSlider; // UI slider for attraction force
let whirlpoolAlpha = 0;
let whirlpoolDirection = 1; // 1 for activate swirl right, -1 for deactivate swirl left
let whirlpoolActive = false;
let voidSpirals = [];


class Particle {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D().mult(random(1, 3));
    this.acc = createVector();
    this.mass = random(1, 3);
    this.r = pow(this.mass, 1.3) * 5;

    let choice = random(particleImgs);
    this.img = choice.img;
    this.type = choice.type;
    this.angle = random(TWO_PI);

    if (this.type === 'kunai') {
      this.rotationSpeed = random(0.1, 0.2);
    } else {
      this.rotationSpeed = random(-0.05, 0.05);
    }
  }

  applyForce(force) {
    let f = p5.Vector.div(force, this.mass);
    this.acc.add(f);
  }

  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.set(0, 0);
    this.angle += this.rotationSpeed;
  }

  show() {
    push();
    translate(this.pos.x, this.pos.y);
    rotate(this.angle);
    imageMode(CENTER);
    let center = createVector(width / 2, height / 2);
    let distFromCenter = this.pos.dist(center);
    let scaleFactor = map(distFromCenter, 0, width / 2, 1, 2);
    let size = this.r * scaleFactor;
    image(this.img, 0, 0, size * 2, size * 2);
    pop();
  }

  offscreen() {
    return (
      this.pos.x < -50 || this.pos.x > width + 50 ||
      this.pos.y < -50 || this.pos.y > height + 50
    );
  }

  energy() {
    return 0.5 * this.mass * this.vel.magSq();
  }
}

class Attractor {
  constructor(x, y, m) {
    this.pos = createVector(x, y);
    this.mass = m;
    this.dragging = false;
    this.offset = createVector(0, 0);
  }

  attract(particle) {
    if (normalSharingan) return createVector(0, 0);

    let force = p5.Vector.sub(this.pos, particle.pos);
    let d = constrain(force.mag(), 5, 25);
    force.normalize();
    let strength = (attractionForce * this.mass * particle.mass) / (d * d);
    force.mult(strength);
    return force;
  }

  show() {
    push();
    translate(this.pos.x, this.pos.y);
    let glowRadius = sqrt(this.mass) * 2 * G;
    noStroke();

    for (let i = 10; i <= glowRadius; i += 2) {
      let alpha = map(i, 10, glowRadius, showTrails ? 180 : 150, 0);
      fill(showTrails ? color(255, 0, 0, alpha) : color(0, 0, 0, alpha));
      ellipse(0, 0, i, i);
    }

    let baseScale = sqrt(this.mass) * 3;
    let imgScale = showTrails ? glowRadius * 0.65 : baseScale;

    rotate(frameCount * -0.05 * G);
    imageMode(CENTER);
    if (normalSharingan) {
      image(normalSharinganImg, 0, 0, imgScale, imgScale);
    } else {
      image(sharinganImg, 0, 0, imgScale, imgScale);
    }
    pop();
  }

  isMouseOver() {
    let d = dist(mouseX, mouseY, this.pos.x, this.pos.y);
    return d < sqrt(this.mass) / 2;
  }

  startDrag() {
    this.dragging = true;
    this.offset = p5.Vector.sub(this.pos, createVector(mouseX, mouseY));
  }

  drag() {
    if (this.dragging) {
      this.pos = createVector(mouseX, mouseY).add(this.offset);
    }
  }

  stopDrag() {
    this.dragging = false;
  }
}

class VoidSpiral {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.lifetime = 60; // 1 second at 60fps
    this.particles = [];

    const maxRadius = dist(0, 0, width, height); // screen diagonal

    for (let i = 0; i < 100; i++) {  // fewer streaks for less density
      let angle = random(TWO_PI);
      let radius = random(width / 2, maxRadius);
      let speed = random(0.15, 0.3);  // faster spin speed
      this.particles.push({
        angle,
        radius,
        speed,
        alpha: 255
      });
    }
  }

  update() {
    for (let p of this.particles) {
      p.angle += p.speed;
      p.radius *= 0.85;   // fast shrink toward center
      if (p.radius < 20) {
        p.alpha *= 0.7;   // fade faster near center
      } else {
        p.alpha *= 0.95;  // normal fade further out
      }
    }
    this.lifetime--;
  }

  show() {
    push();
    translate(this.pos.x, this.pos.y);
    strokeWeight(2);
    strokeCap(ROUND);
    for (let p of this.particles) {
      if (p.alpha < 5) continue;
      let x1 = cos(p.angle) * p.radius;
      let y1 = sin(p.angle) * p.radius;
      let x2 = cos(p.angle + 0.5) * (p.radius * 1.2);
      let y2 = sin(p.angle + 0.5) * (p.radius * 1.2);
      stroke(255, p.alpha);
      line(x1, y1, x2, y2);
    }
    pop();
  }

  isFinished() {
    return this.lifetime <= 0;
  }
}

function displayOverlay() {
  fill(255);
  textSize(14);
  text(`Particles: ${particles.length}`, 10, 20);
  text(`Mode: ${mode}`, 10, 40);
  text(`Force: ${attract ? "Attract" : "Repel"}`, 10, 60);
  text(`Gravity: ${dimension === "earth" ? 9.8 : nf(gravity, 1, 2)}`, 10, 80);
  text(`Attraction Force: ${nf(attractionForce, 1, 2)}`, 10, 100);
  text(`Seed: ${nf(seed, 1, 0)}`, 10, 120);
  text(`Dimension: ${dimension}`, 10, 140);
  text(`Sharingan Mode: ${normalSharingan ? "Normal" : "Mangekyo"}`, 10, 160);
}

function drawGlitchEffect() {
  loadPixels();
  for (let i = 0; i < 30; i++) {
    let x = int(random(width));
    let y = int(random(height));
    let idx = 4 * (y * width + x);
    pixels[idx] = 255;
    pixels[idx + 1] = 255;
    pixels[idx + 2] = 255;
    pixels[idx + 3] = 100;
  }
  updatePixels();
}

function drawWhirlpool(centerX, centerY) {
  noFill();
  stroke(255, whirlpoolAlpha);
  strokeWeight(2);
  let maxRadius = 150;
  for (let i = 0; i < 30; i++) {
    let angle = frameCount * 0.05 * whirlpoolDirection + i * 0.2;
    let r = i * 5;
    let x = centerX + cos(angle) * r;
    let y = centerY + sin(angle) * r;
    ellipse(x, y, r, r);
  }
  if (whirlpoolActive) {
    whirlpoolAlpha = min(255, whirlpoolAlpha + 10);
  } else {
    whirlpoolAlpha = max(0, whirlpoolAlpha - 10);
  }
}

function initializeSimulation(seedVal) {
  seed = seedVal;
  randomSeed(seed);
  noiseSeed(seed);
  particles = [];
  attractors = [];
  for (let i = 0; i < 20; i++) {
    particles.push(new Particle(random(width), random(height)));
  }
  attractors.push(new Attractor(width / 2, height / 2, 500));
  if (mode === "chaotic") {
    attractors.push(new Attractor(random(width), random(height), 500));
  }
}

function applyCustomSeed() {
  let newSeed = int(seedInput.value());
  if (!isNaN(newSeed)) {
    initializeSimulation(newSeed);
  }
}

function changeMode() {
  mode = modeSelector.value();
  initializeSimulation(seed);
}

function changeForce() {
  attract = (forceSelector.value() === "attract");
}

function setup() {
  createCanvas(800, 600);
  createP("Gravity Strength:");
  gravitySlider = createSlider(0, 5, 1, 0.1);
  createP("Attraction Force:");
  attractionSlider = createSlider(0, 10, 1, 0.1);
  createP("Custom Seed:");
  seedInput = createInput();
  seedButton = createButton("Apply Seed");
  seedButton.mousePressed(applyCustomSeed);
  createP("Mode:");
  modeSelector = createSelect();
  modeSelector.option("calm");
  modeSelector.option("chaotic");
  modeSelector.changed(changeMode);
  createP("Force Type:");
  forceSelector = createSelect();
  forceSelector.option("attract");
  forceSelector.option("repel");
  forceSelector.changed(changeForce);
  let trailButton = createButton("Toggle Trails");
  trailButton.mousePressed(() => {
    showTrails = !showTrails;
  });
  let dimensionButton = createButton("Switch Dimension");
  dimensionButton.mousePressed(() => {
    dimension = (dimension === "kamui") ? "earth" : "kamui";
    initializeSimulation(millis());
  });
  let sharinganButton = createButton("Toggle Sharingan");
  sharinganButton.mousePressed(() => {
    normalSharingan = !normalSharingan;

    // Add a void spiral effect centered on the attractor
    let center = attractors[0].pos.copy();
    voidSpirals.push(new VoidSpiral(center.x, center.y));
  });

  initializeSimulation(millis());
}

function draw() {
  const earthGravity = 9.8;
  gravity = gravitySlider.value();
  attractionForce = normalSharingan ? 0 : attractionSlider.value();
  if (showTrails) {
    tint(255, 50);
    image(dimension === "kamui" ? kamuiBgImg : konohaBgImg, 0, 0, width, height);
    noTint();
    fill(10, 5, 25, 30);
    noStroke();
    rect(0, 0, width, height);
  } else {
    image(dimension === "kamui" ? kamuiBgImg : konohaBgImg, 0, 0, width, height);
  }
  swirlAngle += 0.01;
  for (let attractor of attractors) {
    attractor.show();
  }
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    if (dimension === "earth") {
      if (normalSharingan) {
        p.applyForce(createVector(0, p.mass * earthGravity));
      } else {
        for (let a of attractors) {
          let force = a.attract(p);
          if (!attract) force.mult(-1);
          p.applyForce(force);
        }
      }
    } else {
      if (!normalSharingan) {
        for (let a of attractors) {
          let force = a.attract(p);
          if (!attract) force.mult(-1);
          p.applyForce(force);
        }
      }
      p.applyForce(createVector(0, p.mass * gravity));
    }
    for (let i = voidSpirals.length - 1; i >= 0; i--) {
      voidSpirals[i].update();
      voidSpirals[i].show();
      if (voidSpirals[i].isFinished()) {
        voidSpirals.splice(i, 1);
      }
    }

    p.update();
    p.show();
    if (p.offscreen() || p.energy() < 0.5) {
      particles.splice(i, 1);
    }
  }
  for (let i = voidSpirals.length - 1; i >= 0; i--) {
    voidSpirals[i].update();
    voidSpirals[i].show();
    if (voidSpirals[i].isFinished()) {
      voidSpirals.splice(i, 1);
    }
  }
  if (dimension === "kamui") {
    drawGlitchEffect();
  }
  drawWhirlpool(width / 2, height / 2);
  displayOverlay();
}

function mousePressed() {
  if (mouseButton === LEFT) {
    particles.push(new Particle(mouseX, mouseY));
  }
  for (let a of attractors) {
    if (a.isMouseOver()) {
      a.startDrag();
    }
  }
}

function mouseDragged() {
  for (let a of attractors) {
    a.drag();
  }
}

function mouseReleased() {
  for (let a of attractors) {
    a.stopDrag();
  }
}

function preload() {
  sharinganImg = loadImage('sharingan.png');
  particleImgs.push({ img: loadImage('scroll.png'), type: 'scroll' });
  particleImgs.push({ img: loadImage('kunai.png'), type: 'kunai' });
  particleImgs.push({ img: loadImage('shuriken.png'), type: 'shuriken' });
  konohaBgImg = loadImage('konoha.png');
  normalSharinganImg = loadImage('normal_sharingan.png');
  kamuiBgImg = loadImage('Kamui_Dimension.png');
}
